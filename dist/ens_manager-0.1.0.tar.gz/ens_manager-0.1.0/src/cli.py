"""Command-line interface for ENS Manager."""

import click
import questionary
from rich.console import Console
from rich.table import Table
from typing import List, Optional
import os
from dotenv import load_dotenv
import json
from rich.theme import Theme
from rich.style import Style

from .ens_operations import ENSManager

# Create a custom theme for rich
theme = Theme({
    "info": "cyan",
    "warning": "yellow",
    "error": "red",
    "success": "green",
})

console = Console(theme=theme)

def init_manager() -> ENSManager:
    """Initialize ENS Manager with environment variables."""
    load_dotenv()
    return ENSManager(
        provider_url=os.getenv('ETH_PROVIDER_URL'),
        private_key=os.getenv('ETH_PRIVATE_KEY')
    )

def display_name_info(name: str, manager: ENSManager):
    """Display all information about an ENS name."""
    # Gather all information
    address = manager.resolve_name(name)
    owner = manager.get_owner(name)
    resolver = manager.get_resolver(name)
    ttl = manager.get_ttl(name)
    content_hash = manager.get_content_hash(name)
    
    # Common text records
    text_keys = ['email', 'url', 'avatar', 'description', 'notice', 'keywords', 'com.twitter', 'com.github']
    text_records = {}
    for key in text_keys:
        text_records[key] = manager.get_text_record(name, key)
    
    # Create rich table
    table = Table(title=f"ENS Name Information: {name}")
    table.add_column("Property", style="info")
    table.add_column("Value", style="success")
    
    table.add_row("Address", address if address else "[error]Not set[/error]")
    table.add_row("Owner", owner if owner else "[error]Not set[/error]")
    table.add_row("Resolver", resolver if resolver else "[error]Not set[/error]")
    table.add_row("TTL", str(ttl) if ttl else "[error]Not set[/error]")
    table.add_row("Content Hash", content_hash if content_hash else "[error]Not set[/error]")
    
    for key, value in text_records.items():
        if value:
            table.add_row(f"Text: {key}", value)
    
    console.print(table)

def display_name_history(name: str, manager: ENSManager):
    """Display ownership history of an ENS name."""
    events = manager.get_name_history(name)
    
    if not events:
        console.print("[error]✗[/error] No history found for {name}")
        return
    
    table = Table(title=f"History for {name}")
    table.add_column("Type", style="info")
    table.add_column("From/Owner", style="success")
    table.add_column("To", style="info")
    table.add_column("Time", style="warning")
    table.add_column("Block", style="warning")
    
    for event in events:
        if event['type'] == 'Transfer':
            table.add_row(
                event['type'],
                event['from'],
                event['to'],
                event['timestamp'],
                str(event['block'])
            )
        else:  # NewOwner
            table.add_row(
                event['type'],
                event['owner'],
                "",
                event['timestamp'],
                str(event['block'])
            )
    
    console.print(table)

def interactive_menu():
    """Display interactive menu for ENS operations."""
    actions = {
        "Look up ENS information": "info",
        "Resolve ENS name to address": "resolve",
        "Reverse resolve address to ENS name": "reverse",
        "Get owner of ENS name": "owner",
        "Get text record": "get_text",
        "View name history": "history",
        "Exit": "exit"
    }
    
    while True:
        action = questionary.select(
            "What would you like to do?",
            choices=list(actions.keys()),
            style=questionary.Style([
                ('selected', 'bg:blue fg:white'),
                ('pointer', 'fg:blue'),
                ('answered', 'fg:green'),
            ])
        ).ask()
        
        if action == "Exit" or not action:
            break
            
        command = actions[action]
        manager = init_manager()
        
        if command in ["info", "resolve", "owner", "history"]:
            name = questionary.text("Enter ENS name:").ask()
            if not name:
                continue
                
            if command == "info":
                display_name_info(name, manager)
            elif command == "resolve":
                address = manager.resolve_name(name)
                if address:
                    console.print(f"[success]✓[/success] {name} resolves to: {address}")
                else:
                    console.print(f"[error]✗[/error] Could not resolve {name}")
            elif command == "owner":
                owner = manager.get_owner(name)
                if owner:
                    console.print(f"[success]✓[/success] Owner of {name}: {owner}")
                else:
                    console.print(f"[error]✗[/error] Could not get owner of {name}")
            elif command == "history":
                display_name_history(name, manager)
                
        elif command == "reverse":
            address = questionary.text("Enter Ethereum address:").ask()
            if not address:
                continue
            name = manager.reverse_resolve(address)
            if name:
                console.print(f"[success]✓[/success] {address} resolves to: {name}")
            else:
                console.print(f"[error]✗[/error] Could not reverse resolve {address}")
                
        elif command == "get_text":
            name = questionary.text("Enter ENS name:").ask()
            if not name:
                continue
            key = questionary.text("Enter text record key (e.g., email, url, avatar):").ask()
            if not key:
                continue
            value = manager.get_text_record(name, key)
            if value:
                console.print(f"[success]✓[/success] {key} record for {name}: {value}")
            else:
                console.print(f"[error]✗[/error] Could not get {key} record for {name}")
        
        # Add a pause between operations
        questionary.text("Press Enter to continue...").ask()

def main():
    """Main entry point for the CLI."""
    console.print("[bold blue]ENS Manager[/bold blue] - A comprehensive Ethereum Name Service management tool\n")
    
    # Check for environment variables
    if not os.getenv('ETH_PROVIDER_URL'):
        console.print("[error]Error:[/error] ETH_PROVIDER_URL environment variable is not set")
        console.print("Please set it in your .env file or environment variables")
        return
    
    try:
        interactive_menu()
    except KeyboardInterrupt:
        console.print("\nGoodbye! 👋")
    except Exception as e:
        console.print(f"[error]Error:[/error] {str(e)}")

if __name__ == '__main__':
    main()