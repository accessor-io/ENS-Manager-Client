"""Core ENS operations module."""

import asyncio
from typing import Dict, List, Optional, Union, Any
from web3 import Web3
from eth_utils import is_address, to_checksum_address, decode_hex
from web3.middleware import geth_poa_middleware
import os
from dotenv import load_dotenv
import json
from datetime import datetime
from rich.console import Console
import base64
import codecs

console = Console()

class ENSManager:
    """Main class for ENS operations."""

    def __init__(self, provider_url: Optional[str] = None, private_key: Optional[str] = None):
        """Initialize ENS Manager."""
        load_dotenv()
        self.provider_url = provider_url or os.getenv('ETH_PROVIDER_URL')
        self.private_key = private_key or os.getenv('ETH_PRIVATE_KEY')
        
        if not self.provider_url:
            raise ValueError("Provider URL is required")
            
        self.w3 = Web3(Web3.HTTPProvider(self.provider_url))
        self.w3.middleware_onion.inject(geth_poa_middleware, layer=0)
        
        # Initialize ENS
        self.ns = self.w3.ens
        
        if self.private_key:
            self.account = self.w3.eth.account.from_key(self.private_key)
        else:
            self.account = None

    def resolve_name(self, name: str) -> Optional[str]:
        """Resolve ENS name to Ethereum address."""
        try:
            address = self.w3.ens.address(name)
            return address if address else None
        except Exception as e:
            print(f"Error resolving name {name}: {e}")
            return None

    def reverse_resolve(self, address: str) -> Optional[str]:
        """Reverse resolve Ethereum address to ENS name."""
        try:
            if not is_address(address):
                return None
            name = self.w3.ens.name(address)
            return name if name else None
        except Exception as e:
            print(f"Error reverse resolving address {address}: {e}")
            return None

    def get_owner(self, name: str) -> Optional[str]:
        """Get owner of ENS name."""
        try:
            owner = self.w3.ens.owner(name)
            return owner if owner != "0x0000000000000000000000000000000000000000" else None
        except Exception as e:
            print(f"Error getting owner of {name}: {e}")
            return None

    def get_resolver(self, name: str) -> Optional[str]:
        """Get resolver contract address for ENS name."""
        try:
            resolver = self.w3.ens.resolver(name)
            return resolver.address if resolver else None
        except Exception as e:
            print(f"Error getting resolver for {name}: {e}")
            return None

    def get_ttl(self, name: str) -> Optional[int]:
        """Get TTL for ENS name."""
        try:
            node = self.w3.ens.namehash(name)
            registry_address = "0x00000000000C2E074eC69A0dFb2997BA6C7d2e1e"  # ENS Registry address
            registry = self.w3.eth.contract(
                address=registry_address,
                abi=[{
                    "constant": True,
                    "inputs": [{"name": "node", "type": "bytes32"}],
                    "name": "ttl",
                    "outputs": [{"name": "", "type": "uint64"}],
                    "payable": False,
                    "type": "function"
                }]
            )
            ttl = registry.functions.ttl(node).call()
            return ttl
        except Exception as e:
            print(f"Error getting TTL for {name}: {e}")
            return None

    def get_text_record(self, name: str, key: str) -> Optional[str]:
        """Get text record for ENS name."""
        try:
            resolver = self.w3.ens.resolver(name)
            if not resolver:
                return None
            return resolver.functions.text(self.w3.ens.namehash(name), key).call()
        except Exception as e:
            print(f"Error getting text record for {name}: {e}")
            return None

    def get_content_hash(self, name: str) -> Optional[str]:
        """Get content hash for ENS name."""
        try:
            resolver = self.w3.ens.resolver(name)
            if not resolver:
                return None
            
            content_hash = resolver.functions.contenthash(self.w3.ens.namehash(name)).call()
            
            if not content_hash:
                return None
                
            # Decode the content hash
            if len(content_hash) == 0:
                return None
                
            # Convert to hex string
            content_hash_hex = '0x' + content_hash.hex()
            
            # Handle IPFS hashes (0xe3010170 prefix)
            if content_hash_hex.startswith('0xe3010170'):
                # Remove the IPFS prefix and encode as base58
                ipfs_bytes = content_hash[4:]
                import base58
                return f"ipfs://{base58.b58encode(ipfs_bytes).decode('utf-8')}"
            
            # Handle Swarm hashes (0xe40101fa prefix)
            elif content_hash_hex.startswith('0xe40101fa'):
                swarm_bytes = content_hash[4:]
                return f"bzz://{swarm_bytes.hex()}"
                
            return content_hash_hex
            
        except Exception as e:
            print(f"Error getting content hash for {name}: {e}")
            return None

    def set_address(self, name: str, address: str) -> bool:
        """Set address for ENS name."""
        if not self.account:
            raise ValueError("Private key required for this operation")
            
        try:
            if not is_address(address):
                return False
                
            address = to_checksum_address(address)
            tx = self.w3.ens.setup_address(name, address)
            return bool(tx)
        except Exception as e:
            print(f"Error setting address for {name}: {e}")
            return False

    def set_text_record(self, name: str, key: str, value: str) -> bool:
        """Set text record for ENS name."""
        if not self.account:
            raise ValueError("Private key required for this operation")
            
        try:
            resolver = self.w3.ens.resolver(name)
            if not resolver:
                return False
                
            tx = resolver.functions.setText(
                self.w3.ens.namehash(name),
                key,
                value
            ).transact({'from': self.account.address})
            return bool(tx)
        except Exception as e:
            print(f"Error setting text record for {name}: {e}")
            return False

    def set_content_hash(self, name: str, content_hash: str) -> bool:
        """Set content hash for ENS name."""
        if not self.account:
            raise ValueError("Private key required for this operation")
            
        try:
            resolver = self.w3.ens.resolver(name)
            if not resolver:
                return False
                
            tx = resolver.functions.setContenthash(
                self.w3.ens.namehash(name),
                content_hash
            ).transact({'from': self.account.address})
            return bool(tx)
        except Exception as e:
            print(f"Error setting content hash for {name}: {e}")
            return False

    async def batch_resolve(self, names: List[str]) -> Dict[str, Optional[str]]:
        """Resolve multiple ENS names in parallel."""
        tasks = [self.resolve_name(name) for name in names]
        results = await asyncio.gather(*tasks)
        return dict(zip(names, results))

    async def batch_reverse_resolve(self, addresses: List[str]) -> Dict[str, Optional[str]]:
        """Reverse resolve multiple addresses in parallel."""
        tasks = [self.reverse_resolve(addr) for addr in addresses]
        results = await asyncio.gather(*tasks)
        return dict(zip(addresses, results))

    def validate_name(self, name: str) -> bool:
        """Validate ENS name format."""
        try:
            # Basic validation rules
            if not name or len(name) < 3:
                return False
                
            # Must contain at least one dot
            if '.' not in name:
                return False
                
            # Check TLD
            tld = name.split('.')[-1]
            if tld not in ['eth', 'xyz', 'test']:  # Add more valid TLDs as needed
                return False
                
            # Check characters
            allowed = set('abcdefghijklmnopqrstuvwxyz0123456789-.')
            if not set(name.lower()).issubset(allowed):
                return False
                
            # No consecutive dots or hyphens
            if '..' in name or '--' in name:
                return False
                
            # No leading/trailing dots or hyphens
            if name.startswith('.') or name.endswith('.') or \
               name.startswith('-') or name.endswith('-'):
                return False
                
            return True
        except Exception:
            return False

    def get_registration_status(self, name: str) -> Dict[str, Any]:
        """Get detailed registration status."""
        try:
            owner = self.get_owner(name)
            resolver = self.get_resolver(name)
            address = self.resolve_name(name)
            
            return {
                'name': name,
                'available': not bool(owner),
                'owner': owner,
                'resolver': resolver,
                'address': address,
                'valid': self.validate_name(name)
            }
        except Exception as e:
            print(f"Error getting registration status for {name}: {e}")
            return {
                'name': name,
                'error': str(e)
            }

    def get_primary_name(self, address: str) -> Optional[str]:
        """Get primary ENS name for an address."""
        try:
            if not is_address(address):
                return None
                
            address = to_checksum_address(address)
            return self.w3.ens.name(address)
        except Exception as e:
            print(f"Error getting primary name for {address}: {e}")
            return None

    def get_name_history(self, name: str) -> List[Dict[str, Any]]:
        """Get ownership history of an ENS name."""
        try:
            registry = self.w3.ens.registry
            node = self.w3.ens.namehash(name)
            
            # Get all relevant events
            transfer_events = registry.events.Transfer.getLogs(
                fromBlock=0,
                argument_filters={'node': node}
            )
            
            new_owner_events = registry.events.NewOwner.getLogs(
                fromBlock=0,
                argument_filters={'node': node}
            )
            
            # Combine and sort events
            events = []
            
            for event in transfer_events:
                events.append({
                    'type': 'Transfer',
                    'from': event['args']['from'],
                    'to': event['args']['to'],
                    'timestamp': datetime.fromtimestamp(
                        self.w3.eth.get_block(event['blockNumber'])['timestamp']
                    ).isoformat(),
                    'block': event['blockNumber'],
                    'transaction': event['transactionHash'].hex()
                })
            
            for event in new_owner_events:
                events.append({
                    'type': 'NewOwner',
                    'owner': event['args']['owner'],
                    'timestamp': datetime.fromtimestamp(
                        self.w3.eth.get_block(event['blockNumber'])['timestamp']
                    ).isoformat(),
                    'block': event['blockNumber'],
                    'transaction': event['transactionHash'].hex()
                })
            
            # Sort by block number
            events.sort(key=lambda x: x['block'])
            return events
        except Exception as e:
            print(f"Error getting history for {name}: {e}")
            return []