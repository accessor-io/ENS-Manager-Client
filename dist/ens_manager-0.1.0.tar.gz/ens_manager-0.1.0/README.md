# ENS Manager

A comprehensive Ethereum Name Service (ENS) management tool that provides a command-line interface for interacting with ENS names.

## Features

- Interactive menu with arrow key navigation
- Resolve ENS names to Ethereum addresses
- Reverse resolve Ethereum addresses to ENS names
- Get ENS name owner information
- View resolver contract addresses
- Get TTL values
- Manage text records
- Handle content hashes (IPFS/Swarm)
- View name history

## Installation

```bash
# Install globally
pip install -e .

# Or use directly with Poetry
poetry install
```

## Configuration

Create a `.env` file in your home directory or project directory with your Ethereum provider URL:

```env
ETH_PROVIDER_URL=https://mainnet.infura.io/v3/YOUR-PROJECT-ID
# Optional: Add your private key for write operations
ETH_PRIVATE_KEY=your-private-key
```

## Usage

After installation, you can run the tool from anywhere:

```bash
# Run the interactive menu
ens-manager
```

## License

MIT License 